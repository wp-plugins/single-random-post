=== Single Random Post ===
Contributors: dcostalis
Donate link: http://isthisablog.com/
Tags: random, posts
Requires at least: 2.0
Tested up to: 2.7.1
Stable tag: trunk

This plugin will allow you to display a single post selected at random from your post database

== Description ==

This plugin will allow you to display a single post selected at random from your post database

There are no bells and no whistles. 

== Installation ==

1. Upload `single-random-post.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Place `<?php single_random_post(); ?>` in your templates

== Frequently Asked Questions ==

= Why does this even exist? =

Because I had a use for it, and nobody else had made it yet

= Why doesn't it do more? =

Because there are plenty of plugins that do a lot more, but none that do this little without editing

== Screenshots ==

1. An example of showing a random post, with some additional fun code around it